from django.contrib import admin
from .models import Office, Reservation

# Register your models here.

admin.site.register(Office)
admin.site.register(Reservation)