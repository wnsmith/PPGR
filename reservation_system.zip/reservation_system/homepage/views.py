from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, logout
from .models import Office, Reservation
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
from django.db import models

# Create your views here.

@login_required
def home(request):
	offices = Office.objects.all()
	return render(request, 'index.html', {'offices':offices})


def display_reservation(request, office_id):
	offices = Office.objects.all()
	reservations = Reservation.objects.filter(office_id = office_id)
	return render(request, 'index.html', {'reservations':reservations ,'office_id':office_id, 'offices':offices})


def check_availability(reservations):
	print(reservations)
	max_element = 0

	for i in range(len(reservations)):
		if(max_element < int(reservations[i][1])):
			max_element = int(reservations[i][1])

	aux = [0]*(max_element+2)



	for i in range(len(reservations)):
		x = int(reservations[i][0])
		y = int(reservations[i][1])

		aux[x] += 1
		aux[y+1] -=1 

	for i in range(1, max_element):
		aux[i] = aux[i] + aux[i-1]

		if aux[i] > 1:
			# overlap
			return True

	#  no overlaping		
	return False

def set_periodically(reservation, option, date):
	# option = 0 for month, 1 for week
	if not option:
		for i in range(1, 4):
			reservation.pk = None
			reservation.date = datetime.strptime(date, "%Y-%m-%d") + timedelta(days = 7*i)
			reservation.save()

	else:
		for i in range(1, 5):
			reservation.pk = None
			reservation.date = datetime.strptime(date, "%Y-%m-%d") + timedelta(days = i)
			reservation.save()



def check_reservation(request):
	if request.method == 'POST':
		description = request.POST.get('description', False)
		date = request.POST.get('date', False)
		start_time = request.POST.get('start_time', False)
		end_time = request.POST.get('end_time', False)
		period = "one"
		office_id = 4
		

		current_reservation_intervals = []
		current_reservations = Reservation.objects.filter(office_id = office_id, date = date)
		for current_reservation in current_reservations:
			current_reservation_intervals.append((current_reservation.start_time, current_reservation.end_time))

		current_reservation_intervals.append((start_time, end_time))
		if check_availability(current_reservation_intervals):
			print("INVALID")
		else:
			reservation = Reservation(description = description, date = date, start_time = time, duration = duration, owner = request.user, office_id = office_id)
			reservation.save()


			if period != "one":
				if period == "month":
					set_periodically(reservation, 0, date)
				else:
					set_periodically(reservation, 1, date)
		 
			return redirect('homepage:display', office_id = office_id)

	return render(request, 'index.html')