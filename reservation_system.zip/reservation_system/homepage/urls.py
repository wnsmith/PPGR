from django.urls import path
from . import views

app_name = 'homepage'
urlpatterns = [
	path('home/', views.home, name = 'home'),
	path('reservation/<int:office_id>/', views.display_reservation, name = 'display'),
	path('reservation/', views.check_reservation, name = 'check_reservation'),
]
