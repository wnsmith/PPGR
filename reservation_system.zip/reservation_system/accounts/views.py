from django.shortcuts import render, redirect
from . login_backend import LoginBackend
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.contrib.auth import login, logout
from django.contrib import messages

# Create your views here.

def resolve_login(request):
	if request.method == 'POST':
		lb = LoginBackend()

		username = request.POST.get('username', False)
		password = request.POST.get('pass', False)
		user, indicator = lb.authenticate(username = username, password = password)
		if user is not None:
			login(request, user)
			return HttpResponseRedirect(reverse('homepage:home'))

		else:
			if indicator == 'password':
				messages.info(request, 'Incorrect password!')
			else:
				messages.info(request, 'No such user!')
			return HttpResponseRedirect(reverse('accounts:sign_in'))

	return render(request, 'login.html')


def do_logout(request):
	logout(request)
	return HttpResponseRedirect(reverse('accounts:sign_in'))
