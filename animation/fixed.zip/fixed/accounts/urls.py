from django.urls import path
from . import views

app_name = 'accounts'
urlpatterns = [
	path('', views.resolve_login, name = 'sign_in'),
	path('logout/', views.do_logout, name = 'do_logout'),
]