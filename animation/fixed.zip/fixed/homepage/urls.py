from django.urls import path
from . import views

app_name = 'homepage'
urlpatterns = [
	path('home/', views.home, name = 'home'),
	path('home/<int:office_id>/', views.show_office, name = 'show_office'),
	path('home/reserve/', views.add_reservation, name = 'add_reservation'),
	path('home/<int:reservation_id>/delete/', views.delete_reservation, name = 'delete_reservation'),
	path('home/filter/<int:office_id>/<int:time>/', views.filter, name = 'filter'),
]
