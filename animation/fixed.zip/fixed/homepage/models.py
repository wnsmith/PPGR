from django.db import models
from django.contrib.auth.models import User

# Create your models here.


class Office(models.Model):
	name = models.CharField(max_length = 100)
	description = models.TextField(max_length = 200)


class Reservation(models.Model):
	owner = models.ForeignKey(User, on_delete = models.CASCADE)
	office = models.ForeignKey(Office, on_delete = models.CASCADE)
	date = models.DateField()
	start_time = models.TimeField()
	end_time = models.TimeField()
	description = models.TextField(max_length = 200)


 