from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, logout
from .models import Office, Reservation
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
from django.db import models
from dateutil.parser import parse

# Create your views here.

@login_required
def home(request):
	offices = Office.objects.all()
	reservations = Reservation.objects.all()
	return render(request, 'index.html', {'offices':offices, 'user':request.user, 'reservations':reservations})


def show_office(request, office_id):
	offices = Office.objects.all()
	reservations = Reservation.objects.filter(office_id = office_id)
	return render(request, 'index.html', {'reservations':reservations, 'offices':offices, 'user':request.user, 'office_id':office_id})


def add_reservation(request):
	if request.method == "POST":
		start_time = request.POST.get('start_time', False)
		end_time = request.POST.get('end_time', False)
		date = parse(request.POST.get('date', False)).strftime("%Y-%m-%d")
		description = request.POST.get('description', False)
		office_id = request.POST.get('office_name', False)

		radios = [request.POST.get('one', False), request.POST.get('week', False), request.POST.get('month', False)]


		reservation = Reservation(start_time = start_time, end_time = end_time, date = date, description = description, owner = request.user, office_id = office_id)

		current_reservations = Reservation.objects.all()
		time_intervals = [start_time, end_time]
		for current_reservation in current_reservations:
			time_intervals.append([current_reservation.start_time, current_reservation.end_time])

		if not check_availability(time_intervals):
			reservation.save()
			if radios[1] == "on":
				set_periodically(reservation, 1, date)	
			elif radios[2] == "on":
				set_periodically(reservation, 0, date)

			return redirect('homepage:show_office', office_id = office_id)
		else:
			print("INVALID")

	return render(request, "index.html")

def delete_reservation(request, reservation_id):
	reservation = Reservation.objects.get(pk = reservation_id)
	reservation.delete()
	return redirect('homepage:show_office', office_id = 1)

# CHECK TOMOROW - MONDAY
def filter(request, office_id, time):
	# 1 for today, 0 for this week
	today = datetime.today().strftime('%Y-%m-%d')
	if time == 1:
		time_filter = [today]
	else:
		weekday = datetime.today().weekday()
		time_filter = [today + timedelta(days=d) for d in range(5-weekday)]

	reservations = Reservation.objects.filter(date__in = time_filter)
	offices = Office.objects.all()
	return render(request, 'index.html', {'reservations':reservations, 'offices':offices, 'user':request.user, 'office_id':office_id})

def set_periodically(reservation, option, date):
	# option = 0 for month, 1 for week
	if not option:
		for i in range(1, 4):
			reservation.pk = None
			reservation.date = datetime.strptime(date, "%Y-%m-%d") + timedelta(days = 7*i)
			reservation.save()

	else:
		for i in range(1, 5):
			reservation.pk = None
			reservation.date = datetime.strptime(date, "%Y-%m-%d") + timedelta(days = i)
			reservation.save()

# TODO
def check_availability(reservations):
	return False

















