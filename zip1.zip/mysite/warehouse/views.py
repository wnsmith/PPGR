from django.shortcuts import render
from django.http import HttpResponse
from .models import House


# Create your views here.

def index(request):

	houses = House.objects.all()

	return render(request, "index.html", {"houses":houses})


