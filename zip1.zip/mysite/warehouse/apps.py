from django.apps import AppConfig


class WarehouseConfig(AppConfig):
    name = 'warehouse'
