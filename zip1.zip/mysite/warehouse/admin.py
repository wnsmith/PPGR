from django.contrib import admin
from .models import House

# Register your models here.

admin.site.register(House)